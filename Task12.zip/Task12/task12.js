var submit = document.querySelector("input[type='submit']");
var title = document.querySelector("input[name='title']");
var price = document.querySelector("input[name='price']");
var quantity = document.querySelector("input[name='quantity']");
var category = document.querySelector("input[name='category']");
var tbody = document.querySelector("#tbody");
var delete_all = document.querySelector("#delete_all");

var data;
var newData;
var mode = "create";
var index;

function know() {
  if (localStorage.product != null) {
    data = JSON.parse(localStorage.product);
    if (data.length > 0) {
      delete_all.innerHTML = `<button onclick="Delete()">Delete All</button>`;
    } else {
      delete_all.innerHTML = '';
    }
  } else {
    data = [];
    delete_all.innerHTML = '';
  }
}

know();

submit.addEventListener("click", (e) => {
  e.preventDefault();
  newData = {
    title: title.value,
    price: price.value,
    quantity: quantity.value,
    category: category.value,
  };
  
  if (mode == "create") {
    data.push(newData);
  } else {
    data[index] = newData;
    submit.value = "Create";
    mode = "create";
  }
  localStorage.setItem("product", JSON.stringify(data));
  readData();
  know();
  reset();
});

function readData() {
  var row = "";
  for (var i = 0; i < data.length; i++) {
    row += `
      <tr>
        <td>${i + 1}</td>
        <td>${data[i].title}</td>
        <td>${data[i].price}</td>
        <td>${data[i].category}</td>
        <td>${data[i].quantity}</td>
        <td><button onclick="update(${i})" id="update">Update</button></td>
        <td><button onclick="deletee(${i})" id="delete">Delete</button></td>
      </tr>
    `;
  }
  tbody.innerHTML = row;
}
readData();

function Delete() {
  localStorage.clear();
  data.splice(0);
  readData();
  know();
}

function deletee(i) {
  data.splice(i, 1);
  localStorage.setItem("product", JSON.stringify(data));
  readData();
}

function update(i) {
  title.value = data[i].title;
  price.value = data[i].price;
  quantity.value = data[i].quantity;
  category.value = data[i].category;
  submit.value = 'Update';
  mode = "update";
  index = i;
}

function reset() {
  title.value = '';
  price.value = '';
  category.value = '';
  quantity.value = '';
}
